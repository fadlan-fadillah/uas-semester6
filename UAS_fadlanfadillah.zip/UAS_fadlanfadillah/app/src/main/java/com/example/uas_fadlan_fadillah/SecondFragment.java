package com.example.uas_fadlan_fadillah;

import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {
}
