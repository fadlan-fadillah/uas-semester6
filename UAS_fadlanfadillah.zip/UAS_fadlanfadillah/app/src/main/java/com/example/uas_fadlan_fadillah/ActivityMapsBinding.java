package com.example.uas_fadlan_fadillah;

import android.view.LayoutInflater;

public class ActivityMapsBinding {
    public static ActivityMapsBinding inflate(Object inflater) {
        return null;
    }

    public int getRoot() {
        return 0;
    }
}
